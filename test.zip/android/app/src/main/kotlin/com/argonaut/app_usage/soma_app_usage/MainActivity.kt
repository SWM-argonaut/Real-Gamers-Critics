package com.argonaut.real_gamers_critics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
