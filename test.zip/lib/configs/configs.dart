import 'package:flutter/material.dart';

const Map appsFlyerOptions = {
  "afDevKey": "ou35vmsh4JqwKxPtS2jR8o",
  "afAppId": "com.argonaut.real_gamers_critics",
  "isDebug": true
};
const String mixpanelToken = "6f23c9ac597f6f2b29f2ed5b4439185d";
// const String onesiganlAppId = "bf829e05-9686-45f6-ba8e-03c83130e2cb";

// test용 유닛 : ca-app-pub-3940256099942544/6300978111
// 우리 애드몹 유닛 : ca-app-pub-4296117019202334/8236491470
// https://developers.google.com/admob/android/test-ads#sample%5C_ad%5C_units
const String bottomBannerAdUnitId = "ca-app-pub-4296117019202334/8236491470";

const int playtimeToLeaveComment = 60;

const String apiBaseUrl =
    "https://1uuazp5ev1.execute-api.us-east-1.amazonaws.com";

const String playStoreBaseUrl =
    "https://play.google.com/store/apps/details?hl=en_US&gl=US&id=";

Color backgroundColor = Color.fromRGBO(253, 253, 253, 1);
