import 'dart:developer';

import 'package:flutter_test/flutter_test.dart';

import 'package:real_gamers_critics/functions/api/comment.dart';

void main() {
  group("api_test.dart", () {
    // 자신의 모든 커멘츠를 리스트로
    // test("get my comments", () async {
    //   log("${await CommentApi.getAllMyComments()}");
    // });
  });
}
